import axios from 'axios';
import inquirer from 'inquirer';

async function fetchPokemon(name) {
  try {
    const res = await axios.get(`https://pokeapi.co/api/v2/pokemon/${name.toLowerCase()}`);
    const { id, types, height, weight } = res.data;
    console.log(`\n#${id} ${name.toUpperCase()}`);
    console.log(`Tipos: ${types.map(t => t.type.name).join(', ')}`);
    console.log(`Altura: ${height} | Peso: ${weight}\n`);
  } catch {
    console.log('Pokémon não encontrado!');
  }
}

async function run() {
  const { name } = await inquirer.prompt([{ name: 'name', message: 'Nome do Pokémon:' }]);
  await fetchPokemon(name);
}

run();
